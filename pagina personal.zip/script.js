//alert("Bienvenido a mi portfolio!")
const nombre = prompt("Cómo te llamas?")
alert("Hola " + nombre + "! Bienvenido a mi portfolio!")